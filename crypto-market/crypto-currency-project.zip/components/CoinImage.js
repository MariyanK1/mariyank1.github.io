import React from "react";

function Image(props) {
  return <img src={props.image} height="23" width="23" />;
}

export default Image;
