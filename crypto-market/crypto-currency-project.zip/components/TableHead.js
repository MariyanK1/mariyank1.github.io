import React from "react";

function Th() {
  return (
    <thead>
      <tr>
        <th>#</th>
        <th>Name</th>
        <th>Price</th>
        <th>24h</th>
        <th>7d</th>
        <th>Market Cap</th>
        <th>Volume</th>
        <th>Circulating Supply</th>
        <th>Last 7 Days</th>
      </tr>
    </thead>
  );
}

export default Th;
