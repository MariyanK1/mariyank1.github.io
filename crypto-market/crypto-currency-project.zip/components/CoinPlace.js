import React from "react";

function Place(props) {
  return <td id="asc">{props.place + 1}</td>;
}

export default Place;
